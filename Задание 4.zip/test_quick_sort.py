{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "0e2cd15e",
   "metadata": {},
   "outputs": [],
   "source": [
    "from quick_sort import quick_sort\n",
    "\n",
    "def test_empty():\n",
    "    assert quick_sort([]) == []\n",
    "\n",
    "def test_one_element():\n",
    "    assert quick_sort([1]) == [1]\n",
    "\n",
    "def test_sorted():\n",
    "    assert quick_sort([1, 2, 3]) == [1, 2, 3]\n",
    "\n",
    "def test_reverse():\n",
    "    assert quick_sort([3, 2, 1]) == [1, 2, 3]\n",
    "\n",
    "def test_random():\n",
    "    assert quick_sort([5, 1, 4, 2]) == [1, 2, 4, 5]\n",
    "\n",
    "def test_duplicates():\n",
    "    assert quick_sort([3, 1, 2, 3]) == [1, 2, 3, 3]"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
