{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "0e2cd15e",
   "metadata": {},
   "outputs": [],
   "source": [
    "def quick_sort(numbers):\n",
    "    \"\"\"\n",
    "    Быстрая сортировка без рекурсии.\n",
    "    Используется стек списков.\n",
    "    \"\"\"\n",
    "\n",
    "    stack = [numbers]\n",
    "    result = []\n",
    "\n",
    "    while stack:\n",
    "        current = stack.pop()\n",
    "\n",
    "        # если список пустой или из одного элемента — он уже отсортирован\n",
    "        if len(current) <= 1:\n",
    "            result += current\n",
    "            continue\n",
    "\n",
    "        pivot = current[0]\n",
    "        left = []\n",
    "        right = []\n",
    "\n",
    "        # делю элементы относительно pivot\n",
    "        for x in current[1:]:\n",
    "            if x < pivot:\n",
    "                left.append(x)\n",
    "            else:\n",
    "                right.append(x)\n",
    "\n",
    "        # кладу задачи обратно в стек\n",
    "        stack.append(right)\n",
    "        stack.append([pivot])\n",
    "        stack.append(left)\n",
    "\n",
    "    return result\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
